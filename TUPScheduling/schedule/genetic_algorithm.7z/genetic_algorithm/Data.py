from dataclasses import dataclass, field
from typing import ClassVar

@dataclass
class RawClass:
    pass

@dataclass
class Professor:
    pass

@dataclass
class Section:
    pass

@dataclass
class Subject:
    pass

@dataclass
class Room:
    pass

@dataclass
class Slot:
    pass
