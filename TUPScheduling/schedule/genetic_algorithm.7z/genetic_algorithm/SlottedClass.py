class SlottedClass:
    def __init__(self, prof_id, room_name, day, section_id, subject_id, starting_time):
        self.prof_id = prof_id
        self.room_name = room_name,
        self.day = day
        self.section_id = section_id
        self.subject_id = subject_id
        self.starting_time = starting_time