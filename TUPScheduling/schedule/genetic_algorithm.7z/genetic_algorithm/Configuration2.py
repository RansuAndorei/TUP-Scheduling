from TUPScheduling.base.models import CourseCurriculum, Sections, Rooms, BasePage, Subjects, SubjectsOrderable, Departments
from TUPScheduling.accounts.models import Professors

