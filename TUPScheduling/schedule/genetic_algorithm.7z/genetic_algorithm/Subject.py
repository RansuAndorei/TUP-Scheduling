class Subject:
  
    def __init__(self, id, name):
        self.Id = id
        self.Name = name
        